#!/usr/bin/python2

import sys
print(sys.version)
