README_mac.txt for version 8.2 of Vim: Vi IMproved.

This file explains the installation of Vim on MacOS systems.
See "README.txt" for general information about Vim.

To build from source get the files with git from https://github.com/vim/vim.
The find the instructions in src/INSTALLmac.txt.

Installing Vim using Homebrew:
1. Install Homebrew from http://brew.sh/
2. Install the latest Vim with:
	brew install vim
